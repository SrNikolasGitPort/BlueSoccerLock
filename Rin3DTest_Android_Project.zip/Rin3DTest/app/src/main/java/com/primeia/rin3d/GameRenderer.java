package com.primeia.rin3d;

import android.content.Context;
import android.opengl.*;
import android.os.SystemClock;
import java.nio.*;
import java.util.*;

public class GameRenderer implements GLSurfaceView.Renderer {
    final Context context;
    SimpleMesh cube, sphere;
    float[] proj=new float[16], view=new float[16], model=new float[16], pv=new float[16];
    float px=0, pz=4, ballX=0, ballY=.35f, ballZ=2.4f;
    float ballVX=0, ballVY=0, ballVZ=0;
    float gkX=0, gkV=0;
    float inX=0,inY=0;
    long last;
    int goals=0;
    float dribbleTime=0, dashTime=0, curveSpin=0;

    public GameRenderer(Context c){ context=c; }

    public void setInput(float x,float y){inX=x; inY=y;}
    public void skill(int id){
        if(id==1) { // Curve Shot
            if(Math.abs(ballVZ)<.1f && Math.abs(ballZ-pz)<2.2f) {
                ballX=px; ballZ=pz-1.0f; ballY=.45f;
                ballVX=inX*2.0f + (px>=0?-1.6f:1.6f);
                ballVY=2.5f; ballVZ=-11f; curveSpin=(px>=0?-1:1)*5.5f;
            }
        } else if(id==2) {
            dribbleTime=1.5f;
        } else if(id==3) {
            dashTime=.45f;
        }
    }

    @Override public void onSurfaceCreated(GL10 gl, EGLConfig cfg){
        GLES20.glClearColor(.025f,.05f,.08f,1);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        cube=SimpleMesh.cube();
        sphere=SimpleMesh.sphere(12,8);
        last=SystemClock.uptimeMillis();
    }

    @Override public void onSurfaceChanged(GL10 gl,int w,int h){
        GLES20.glViewport(0,0,w,h);
        Matrix.perspectiveM(proj,0,52f,(float)w/h,.1f,100f);
    }

    @Override public void onDrawFrame(GL10 gl){
        long now=SystemClock.uptimeMillis();
        float dt=Math.min(.033f,(now-last)/1000f); last=now;
        update(dt);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);

        float camX=px*.35f, camY=7.0f, camZ=11.5f;
        Matrix.setLookAtM(view,0,camX,camY,camZ,px,0,0,0,1,0);
        Matrix.multiplyMM(pv,0,proj,0,view,0);

        drawBox(0,-.2f,0,8,.35f,22, new float[]{.08f,.36f,.13f,1});
        drawBox(0,-.02f,0,8.05f,.08f,22.05f,new float[]{.12f,.48f,.18f,1});

        // center line and penalty area
        drawBox(0,.03f,0,.035f,.02f,22,new float[]{.9f,.95f,.95f,1});
        drawBox(0,.03f,-7.4f,6.0f,.02f,.035f,new float[]{.9f,.95f,.95f,1});
        drawBox(-3,.03f,-8.8f,.035f,.02f,2.8f,new float[]{.9f,.95f,.95f,1});
        drawBox(3,.03f,-8.8f,.035f,.02f,2.8f,new float[]{.9f,.95f,.95f,1});
        drawBox(-3,.03f,-7.4f,6,.02f,.035f,new float[]{.9f,.95f,.95f,1});
        drawBox(3,.03f,-7.4f,.035f,.02f,2.8f,new float[]{.9f,.95f,.95f,1});

        // goal
        drawBox(-3.2f,1.6f,-10, .12f,3.2f,.12f,new float[]{1,1,1,1});
        drawBox(3.2f,1.6f,-10, .12f,3.2f,.12f,new float[]{1,1,1,1});
        drawBox(0,3.2f,-10, 3.3f,.12f,.12f,new float[]{1,1,1,1});
        drawBox(0,1.6f,-9.85f,3.2f,3.2f,.05f,new float[]{.55f,.75f,.95f,.25f});

        // Rin
        drawBox(px,.75f,pz,.75f,1.5f,.5f,new float[]{.035f,.10f,.22f,1});
        drawBox(px,1.65f,pz,.48f,.48f,.48f,new float[]{.72f,.80f,.86f,1});

        // goalkeeper
        drawBox(gkX,.8f,-9.25f,.7f,1.6f,.5f,new float[]{.72f,.08f,.12f,1});
        drawBox(gkX,1.7f,-9.25f,.45f,.45f,.45f,new float[]{.9f,.75f,.65f,1});

        drawSphere(ballX,ballY,ballZ,.32f,new float[]{.95f,.95f,.95f,1});
    }

    void update(float dt){
        float speed=(dribbleTime>0?7.0f:4.0f);
        if(dashTime>0){ speed=14; dashTime-=dt; }
        px += inX*speed*dt;
        pz += inY*speed*dt;
        px=Math.max(-3.5f,Math.min(3.5f,px));
        pz=Math.max(-1.5f,Math.min(8.0f,pz));
        if(dribbleTime>0) dribbleTime-=dt;

        // ball follows Rin until a shot
        if(Math.abs(ballVZ)<.1f) {
            ballX=px; ballZ=pz-1.0f; ballY=.35f;
        } else {
            ballVX += curveSpin*dt;
            ballX += ballVX*dt;
            ballVY -= 9.8f*dt;
            ballY += ballVY*dt;
            ballZ += ballVZ*dt;
            if(ballY<.32f){ballY=.32f; ballVY=Math.abs(ballVY)*.55f;}
            if(Math.abs(ballX)>3.8f){ballX=Math.signum(ballX)*3.8f; ballVX*=-.65f;}
            if(ballZ < -9.5f) {
                if(Math.abs(ballX-gkX)<1.05f && ballY<2.3f) {
                    ballVZ=5.5f; ballVX=(ballX-gkX)*3.5f; ballVY=3.0f; curveSpin=0;
                } else if(Math.abs(ballX)<3.2f && ballY<3.2f) {
                    goals++; resetBall();
                } else { ballVZ=5.0f; ballVY=2.5f; }
            }
        }

        // AI goalkeeper: anticipates ball x and guards the goal line.
        float target=gkX;
        if(ballVZ<0 && ballZ<-3) target=ballX + ballVX*.18f;
        target=Math.max(-2.65f,Math.min(2.65f,target));
        gkV += (target-gkX)*16*dt;
        gkV *= .84f;
        gkX += gkV*dt;
        gkX=Math.max(-2.65f,Math.min(2.65f,gkX));
    }

    void resetBall(){
        ballVX=ballVY=ballVZ=curveSpin=0; ballX=px; ballY=.35f; ballZ=pz-1;
    }

    void drawBox(float x,float y,float z,float sx,float sy,float sz,float[] color){
        Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z); Matrix.scaleM(model,0,sx,sy,sz);
        cube.draw(pv,model,color);
    }
    void drawSphere(float x,float y,float z,float s,float[] color){
        Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z); Matrix.scaleM(model,0,s,s,s);
        sphere.draw(pv,model,color);
    }
}
