package com.primeia.rin3d;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.opengl.GLSurfaceView;
import android.view.*;
import android.content.Context;
import java.util.Locale;

public class MainActivity extends Activity {
    GameView game;
    HudView hud;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        FrameLayout root = new FrameLayout(this);
        game = new GameView(this);
        hud = new HudView(this, game);
        root.addView(game, new FrameLayout.LayoutParams(-1,-1));
        root.addView(hud, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
    }

    @Override protected void onPause() { super.onPause(); game.onPause(); }
    @Override protected void onResume() { super.onResume(); game.onResume(); }

    public static class HudView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        GameView game;
        float jx=0, jy=0;
        boolean dragging=false;
        RectF curve=new RectF(), dribble=new RectF(), dash=new RectF();
        float baseX, baseY;

        HudView(Context c, GameView g) { super(c); game=g; p.setTypeface(Typeface.create("sans",Typeface.BOLD)); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }

        void txt(Canvas c, String s, float x, float y, float size) {
            p.setTextSize(size); p.setColor(Color.WHITE); p.setStyle(Paint.Style.FILL);
            p.setShadowLayer(5,0,2,Color.BLACK); c.drawText(s,x,y,p); p.clearShadowLayer();
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w=getWidth(), h=getHeight();
            baseX=105; baseY=h-105;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(0x88FFFFFF);
            c.drawCircle(baseX,baseY,72,p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xAAFFFFFF);
            c.drawCircle(baseX+jx*48,baseY+jy*48,28,p);

            float r=70, gap=20, bx=w-95;
            dash.set(bx-r,bx*0+h-95-r,bx+r,h-95+r);
            curve.set(w-95-2*(r+gap),h-95-r,w-95-2*(r+gap)+2*r,h-95+r);
            dribble.set(w-95-(r+gap),h-95-r,w-95-(r+gap)+2*r,h-95+r);

            button(c,curve,"CURVE","SHOT",0xCC123B6B);
            button(c,dribble,"DRIBBLE","",0xCC143E68);
            button(c,dash,"DASH","",0xCC1B557A);

            txt(c,"RIN • TEST 01",25,45,25);
            txt(c,"AI GOALKEEPER",25,75,15);
            txt(c,"CURVE SHOT",curve.centerX()-52,curve.centerY()-3,14);
            txt(c,"DRIBBLE",dribble.centerX()-38,dribble.centerY()+5,14);
            txt(c,"DASH",dash.centerX()-20,dash.centerY()+5,15);
            txt(c,String.format(Locale.US,"GOALS  %d",game.renderer.goals),w/2f-55,42,22);
            txt(c,"3 SKILLS • SCORE THE GOAL",w/2f-125,68,13);
        }

        void button(Canvas c, RectF r, String a, String b, int color) {
            p.setStyle(Paint.Style.FILL); p.setColor(color); c.drawCircle(r.centerX(),r.centerY(),r.width()/2,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(0xAAFFFFFF); c.drawCircle(r.centerX(),r.centerY(),r.width()/2,p);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            float x=e.getX(), y=e.getY();
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE) {
                if(Math.hypot(x-baseX,y-baseY)<110) {
                    dragging=true;
                    jx=Math.max(-1,Math.min(1,(x-baseX)/72f));
                    jy=Math.max(-1,Math.min(1,(y-baseY)/72f));
                    game.renderer.setInput(jx,jy);
                    invalidate(); return true;
                }
            }
            if(e.getAction()==MotionEvent.ACTION_UP) {
                if(dragging) { dragging=false; jx=jy=0; game.renderer.setInput(0,0); invalidate(); return true; }
                if(curve.contains(x,y)) game.renderer.skill(1);
                else if(dribble.contains(x,y)) game.renderer.skill(2);
                else if(dash.contains(x,y)) game.renderer.skill(3);
                return true;
            }
            return true;
        }
    }
}
