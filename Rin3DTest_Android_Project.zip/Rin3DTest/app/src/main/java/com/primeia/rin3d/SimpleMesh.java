package com.primeia.rin3d;

import android.opengl.GLES20;
import java.nio.*;
import java.util.*;

public class SimpleMesh {
    FloatBuffer vb;
    ShortBuffer ib;
    int program, pos, mvp, color;
    int count;

    static final String VS =
        "uniform mat4 uMVP; attribute vec3 aPos; void main(){gl_Position=uMVP*vec4(aPos,1.0);}";
    static final String FS =
        "precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}";

    SimpleMesh(float[] v, short[] idx){
        vb=ByteBuffer.allocateDirect(v.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        vb.put(v).position(0);
        ib=ByteBuffer.allocateDirect(idx.length*2).order(ByteOrder.nativeOrder()).asShortBuffer();
        ib.put(idx).position(0); count=idx.length;
        program=ShaderUtil.program(VS,FS);
        pos=GLES20.glGetAttribLocation(program,"aPos");
        mvp=GLES20.glGetUniformLocation(program,"uMVP");
        color=GLES20.glGetUniformLocation(program,"uColor");
    }

    void draw(float[] pv,float[] model,float[] c){
        float[] out=new float[16];
        android.opengl.Matrix.multiplyMM(out,0,pv,0,model,0);
        GLES20.glUseProgram(program);
        GLES20.glEnableVertexAttribArray(pos);
        GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,12,vb);
        GLES20.glUniformMatrix4fv(mvp,1,false,out,0);
        GLES20.glUniform4fv(color,1,c,0);
        GLES20.glDrawElements(GLES20.GL_TRIANGLES,count,GLES20.GL_UNSIGNED_SHORT,ib);
        GLES20.glDisableVertexAttribArray(pos);
    }

    static SimpleMesh cube(){
        float[] v={
            -.5f,-.5f,-.5f, .5f,-.5f,-.5f, .5f,.5f,-.5f, -.5f,.5f,-.5f,
            -.5f,-.5f,.5f, .5f,-.5f,.5f, .5f,.5f,.5f, -.5f,.5f,.5f};
        short[] i={0,1,2,2,3,0,1,5,6,6,2,1,5,4,7,7,6,5,4,0,3,3,7,4,3,2,6,6,7,3,4,5,1,1,0,4};
        return new SimpleMesh(v,i);
    }

    static SimpleMesh sphere(int rings,int segs){
        ArrayList<Float> vv=new ArrayList<>(); ArrayList<Short> ii=new ArrayList<>();
        for(int r=0;r<=rings;r++){
            double th=Math.PI*r/rings;
            for(int s=0;s<=segs;s++){
                double ph=2*Math.PI*s/segs;
                vv.add((float)(Math.sin(th)*Math.cos(ph)));
                vv.add((float)Math.cos(th));
                vv.add((float)(Math.sin(th)*Math.sin(ph)));
            }
        }
        int row=segs+1;
        for(int r=0;r<rings;r++) for(int s=0;s<segs;s++){
            short a=(short)(r*row+s), b=(short)(a+1), c=(short)(a+row), d=(short)(c+1);
            ii.add(a);ii.add(c);ii.add(b); ii.add(b);ii.add(c);ii.add(d);
        }
        float[] vf=new float[vv.size()]; for(int k=0;k<vf.length;k++)vf[k]=vv.get(k);
        short[] ix=new short[ii.size()]; for(int k=0;k<ix.length;k++)ix[k]=ii.get(k);
        return new SimpleMesh(vf,ix);
    }
}
