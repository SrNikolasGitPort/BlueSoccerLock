package com.primeia.rin3d;

import android.content.Context;
import android.opengl.GLSurfaceView;

public class GameView extends GLSurfaceView {
    final GameRenderer renderer;
    public GameView(Context c) {
        super(c);
        setEGLContextClientVersion(2);
        renderer=new GameRenderer(c);
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }
}
