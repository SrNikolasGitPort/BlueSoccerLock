package com.primeia.rin3d;
import android.opengl.GLES20;

public class ShaderUtil {
    static int shader(int type,String src){
        int s=GLES20.glCreateShader(type);
        GLES20.glShaderSource(s,src); GLES20.glCompileShader(s);
        int[] ok=new int[1]; GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,ok,0);
        if(ok[0]==0){String e=GLES20.glGetShaderInfoLog(s); GLES20.glDeleteShader(s); throw new RuntimeException(e);}
        return s;
    }
    static int program(String vs,String fs){
        int p=GLES20.glCreateProgram();
        GLES20.glAttachShader(p,shader(GLES20.GL_VERTEX_SHADER,vs));
        GLES20.glAttachShader(p,shader(GLES20.GL_FRAGMENT_SHADER,fs));
        GLES20.glLinkProgram(p);
        return p;
    }
}
